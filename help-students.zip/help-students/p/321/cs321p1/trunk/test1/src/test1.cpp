//============================================================================
// Name        : test1.cpp
// Author      : Joshua Parep
// Version     :
// Copyright   : No copy right
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <cstring>
#include <string>

using namespace std;

char f(char c){
	char sum = 0;
		if(c == '\0')
			return 0;
		if((c >='A' & c <= 'Z' & c <= 'Z') | (c >= 'a' && c <= 'z'))
            for(int i = 0; c!='\0'; c++)
		      sum = f(c)+1;
		return sum;

}

int main() {

	string word;

	while(cin >> word)
	   cout <<f(word.c_str());

	cout <<"Mahalo";
	return 0;
}
