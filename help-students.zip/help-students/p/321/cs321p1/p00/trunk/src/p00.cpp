//============================================================================
// Name        : p00.cpp
// Author      : Joshua Parep
// Version     :
// Copyright   : No copy right, but do not copy from others
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

/**
 * Sample Program
 */
int main() {
	cout << "Joshua Parep" << endl;
	return 0;
}
