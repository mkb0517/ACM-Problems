/**
 * p03.h
 *
 *      Author: Joshua Parep
 */

/**
 * This class has queens function that find 92 solutions recursively
 * It has a private variable that assigns 8 queens in each position, and
 * three member functions check and position all 8 queens so that none of the queen
 * attack each other.
 */
class p03 {
public:
	unsigned long long int square;
	/**
	 * this is a default constructor for p03 class. The variable square is
	 * declared into unsigned long long while is declared into eight queens of array.
	 */
     p03(){
    	 square= 0ULL;
    	 board = new int[8];
     }
	/**
	 * This function recursively find 92 solutions.
	 * It calls the function that puts the queens recursively
	 * and displays all 92 possible outcomes.
	 */
	static void queens(void (*f)(unsigned long long int)) {
		p03 obj;

		obj.putQueen(0,f);
	}
	/**
	 * this function puts the in one position and then move into another
	 * position and place another queen whenever it is safe. This function
	 * also recursively call to back track the queens.
	 */
	void putQueen( int column, void (*f)(unsigned long long int)){

		if (column == 8) {

			for (int row = 0; row < 8; row++){
                square = square^(1ULL<<(8* row + board[row]));
			}
			f(square);
			square = 0;

		}
		else{

           for(int row = 0; row < 8; row++){
        	   if(isGood(column, row)){
        		   board[column] = row;
        		   putQueen(column + 1, f);
        	   }
           }
		}
	}
/**
 * this function check whether the queen that you are going to place in the board is safe or not
 * If the other queens in the board are going to attack it then return false
 * else it returns true if it is safe to insert it.
 */
	bool isGood(int QNumber, int rlocation){
		for(int row =0; row < QNumber; row++){
           int p = board[row];
           if( p == rlocation || p == rlocation - (QNumber - row) || p == rlocation + (QNumber - row))
        	   return false;
		}
		return true;
	}


private:
	int* board;

};
