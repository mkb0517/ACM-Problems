/**
 * p05.h
 *
 * @author: Joshua Parep
 */
/**
 * This is a tree class of AVL tree containing private functions
 * which are called by the public functions.
 */
template<typename T = int>
class tree {
public:
	/**
	 * This is a constructor function calling the delete function
	 */
	~tree(){
		del();
	}
	/**
	 * This is a node struct containing all pointers and public member variables
	 * and the constructor with default values
	 */
	struct node {
		T data;
		signed tag; // the balance factor. negative if the left is taller, positive if right.
		node *left, *right;   // you may add a constructor and destructor, etc.
		//node();
		//~node();
		/**
		 * This is a constructor and the public member variables are initialized with default values
		 */
		node(T data) :
				data(data), tag(0), left(nullptr), right(nullptr) {
		}
	};
	/**
	 ** This function call f(node) for each node in the list in order.
	 */
	template<typename fn>
	void inorder(fn f) const {
		inorder(f, root);
	}
/**
 * This function call f(node) for each node in the list in pre-order.
 */
	template<typename fn>
	void preorder(fn f) const {
		preorder(f, root);
	}
	/**
	 * This function call f(node) for each node in the list in post-order.
	 */
	template<typename fn>
	void postorder(fn f) const {
		postorder(f, root);
	}
	/**
	 * This function calls the rotate-right function with the root parameter is passed on it.
	 */
	void rotateRight() {
		rotateRight(root);
	}
	/**
	 * This function calls the rotate-left function with the root parameter is passed on it.
	 */
	void rotateLeft() {
		rotateLeft(root);
	}
    /**
     * This function calls the rebalance function with the root parameter is passed on it.
     */
	void rebalance() {
		 rebalance(root);
	}
	/**
	 * This function calls the growth function with the root and p parameter are passed on it.
	 */
	void growth(node *&p) {
		growth(p, root);
	}
    /**
     * This function calls the insert function with the root and n parameter are passed on it.
     */
	void ins(T n) {
		ins(n, root);
	}
	/**
	 * This function calls the delete function which delete a node containing n.
	 */
	void del(T n) {
		del(n, root);
	}
	/**
	 * This function calls the delete function which delete all the node.
	 */
	void del() {
		del(root);
	}

private:
	node* root;
	/**
	 * This function call f(node) for each node in the list in order. It call the node in the left side
	 * first, node in the root, and then node in the right.
	 */
	template<typename fn>
	void inorder(fn f, node* p) const {
		if(!p)return;
		else{
			inorder(f,p->left);
			f(p);
			inorder(f,p->right);
			}
	}
	/**
	 * This function call f(node) for each node in the list in order. It call the node in the root side
	 * first, node in the left, and then node in the right.
	 */
	template<typename fn>
	void preorder(fn f, node* p) const {
		// TODO: call f(node) for each node in the list instead of the sample code below
		if (!p)
			return;
		else {
			f(p);
			inorder(f, p->left);
			inorder(f, p->right);
		}
	}
	/**
	 * This function call f(node) for each node in the list in order. It call the node in the left side
	 * first, node in the right, and then node in the root.
	 */
	template<typename fn>
	void postorder(fn f, node* p) const {
		if (!p)
			return;
		else {
			postorder(f, p->left);
			postorder(f, p->right);
			f(p);
		}
	}
	/**
	 * This function rotate the tree to the right side if the node on the left side of the
	 * tree is taller than the right side.
	 */
	void rotateRight(node *&p) {
		node* q = p;
		p = q->left;
		q->left = p->right;
		p->right = q;
	}
	/**
	 * This function rotate the tree to the left side if the node on the right side of the
	 * tree is taller than the left side.
	 */
	void rotateLeft(node *&p) {
		node* q = p;
		p = q->right;
		q->right = p->left;
		p->left = q;
	}
	/**
	 * This function check every cases and rebalance the tree. If the tree is tall in the right side it call the
	 * rotate right function and rebalance the tree and vise versa for the unbalance tree on the left side.
	 */
	signed rebalance(node* &p) {
		switch (p->tag) {
		//right sub tree is higher than left sub tree
		case -2:
			switch (p->left->tag) {
			case -1:
				rotateRight(p);
				p->right->tag = p->tag = 0;
				return -1;
			case 0:
				rotateRight(p);
				p->tag = -1;
				p->right->tag = -1;
				return 0;

			case 1:
				rotateLeft(p->left);
				rotateRight(p);
				p->left->tag = p->tag == 0;
				return -1;
			}
			break;
		case 2:
			switch (p->right->tag) {
			case -1:
				rotateRight(p->right);
				rotateLeft(p);
				p->left->tag = p->tag == 0;
				return -1;

			case 0:
				rotateLeft(p);
				p->tag = -1;
				p->left->tag = 1;
				p->tag = -1;
				return 0;
			case 1:
				rotateLeft(p);
				p->tag = p->left->tag = 0;
				return -1;
			}
			break;
		}
		return 0;
	}
    /**
     * This is a growth function. When storing more smaller data will increase the left side of the tree.
     * When storing more greater data will increase the right side of the tree.
     */
	signed growth(signed leftGrowth, node *&p, signed rightGrowth) {
		//do the steps in the web page
		int L = 0, R = 0;
		if (p->tag > 0)
			L = -p->tag;
		else
			R = p->tag;
		L += leftGrowth;
		R += rightGrowth;
		p->tag = R-L;
		signed increase = R > L ? R : L;
		return increase + rebalance(p);
		return 0;
	}
	/**
	 * This function inserts a node containing n into the tree list.
	 */
	signed ins(T n, node* &p) {
		if (!p){
		   p = new node(n);
		   return 1;
			}
		else if (n < p->data){
			return growth(ins(n, p->left), p, 0);
		}
		else if (n > p->data){
		    return growth(0, p, ins(n, p->right));
		}
		else if(n == p->data){
			return 0;
		}
		return 0;
	}
	/**
	 * This function delete a node containing n in the tree.
	 */
	signed del(T n, node* &p) {
		if (!p)
			return 0;
		else if (n < p->data)
			return growth(del(n, p->left), p, 0);
		else if (n > p->data)
			return growth(0, p, del(n, p->right));

		else if (n == p->data) {
			if (!p->right) {
				node* temp = p;
				p = p->left;
				delete temp;
				return -1;
			} else
				return growth(0, p, delMin(p->data, p->right));
		}
		return 0;
	}
	/**
	 * This function deletes all the nodes in tree.
	 */
	signed del(node* &p) {
		if(!p) return 0;
				  del(p->right);
				  del(p->left);
				  delete p;
				  p = nullptr;
				  return 0;
		}
	/**
	 * This function deletes the minimum value from the tree. If you try to delete the root then the
	 * minimum node on the right side will go and replace the root.
	 */
    signed delMin(T &n, node* &p){
			if(p->left) {
				return growth(delMin(n, p->left), p, 0);
			}
			else {
			n = p->data;
			node* temp = p;
			p = p->right;
			delete temp;
			return -1;
			}
		}

public:
	/**
	 * This is a default constructor function for tree class.
	 * It assign the member variable, root, to null pointer as a default value.
	 */
	tree() {
		root = nullptr;
	}
};
