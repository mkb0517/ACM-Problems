/**
 * p05.h
 *
 * @author: Joshua Parep
 */
/**
 * This is a tree class of 2-3 tree containing private functions
 * which are called by the public functions.
 */
// TODO: add functionality to the stub functions in this class.
template<typename T = int>
class tree {
public:
	/**
	 * This is a node struct containing all pointers and public member variables
	 * and the constructor with default values
	 */
	struct node {
		enum {
			LEAF1 = 0x10, INTERIOR12 = 0x12, LEAF2 = 0x20, INTERIOR23 = 0x23
		} type;
		T data[2];
		node* child[3];
		node(T value) :
				type { LEAF1 }, data { value }, child { nullptr } {
		}
		//node()

		// TODO: add desired constructors, etc. & comment
	}*root = nullptr;
	/**
	 * This function calls the order().
	 */
	template<typename fn>
	void inorder(fn f) {
		inorder(f, root);
	}
	/**
	 * This function calls the preorder().
	 */
	template<typename fn>
	void preorder(fn f) {
		preorder(f, root);
	}

	/**
	 * This function calls the postorder().
	 */
	template<typename fn>
	void postorder(fn f) {
		postorder(f, root);
	}
	/**
	 * This function calls the ins()
	 */
	void ins(T value) {
		ins(value, root);
		//p->type = node::LEAF2;

	}
	/**
	 * This function calls the del() function that deletes each element from the list
	 */
	void del(T value) {
		del(value, root);
	}
	/**
	 * This function calls the del() function that deletes all
	 */
	void del() {
		del(root);
	}

private:
	/**
	 * This function call f(node) for each node in the list in order. It call the node in the left side
	 * first, node in the root, and then node in the right.
	 */
	template<typename fn>
	void inorder(fn f, const node* const &p) {
		if (!p)
			return;
		inorder(f, p->child[0]);
		for (int childcount = p->type & 0xF, i = 1; i < childcount; i++) {
			f(p, i - 1); // the extra parameter for the visitor function f for in-order traversal is index
			inorder(f, p->child[i]);
		}
	}
	/**
	 * This function call f(node) for each node in the list pre_order. It call the node in the root side
	 * first, node in the left, and then node in the right.
	 */
	template<typename fn>
	void preorder(fn f, const node* const &p) {
		if (!p)
			return;
		f(p);
		for (int childcount = p->type & 0xF, i = 0; i < childcount; i++) {
			preorder(f, p->child[i]); // preorder and postorder visitors don't need the index parameter.
		}
	}
	/**
	 * This function call f(node) for each node in the list in post order. It call the node in the left side
	 * first, node in the right, and then node in the root.
	 */
	template<typename fn>
	void postorder(fn f, node* p) const {
		if (!p)
			return;

		for (int childcount = p->type & 0xF, i = 0; i < childcount; i++) {
			postorder(f, p->child[i]); // preorder and postorder visitors don't need the index parameter.
		}
		f(p);
	}
	/**
	 * This function inserts a node containing n into the tree list.
	 */
	void ins(T n, node* &p) {


	}
	/**
	 * This function delete a node containing n in the tree.
	 */
	void del(T n, node* &p) {

	}
	/**
	 * This function deletes all the nodes in tree.
	 */
	void del(node* &p) {

	}
	/**
	 * This function deletes the minimum value from the tree. If you try to delete the root then the
	 * minimum node on the right side will go and replace the root.
	 */
	void delMin(T &n, node* &p) {

	}

};
