/**
 * p05.h
 *
 * @author: Joshua Parep
 */
/**
 * This is a tree class of AVL tree containing private functions
 * which are called by the public functions.
 */
template<typename T>
class graph {
	// TODO: add whatever additional members are needed
public:
	int nodes;
	/**
		 * This function is the assign function of the graph of this class
		 */
	graph() {
		root = nullptr;
		nodes = 0;
	}
	struct adj_list;
	/**
		 * This is a node struct containing all pointers and public member variables
		 * and the constructor with default values
		 */
	struct node {
		//no. of vertices and
		T data;
		int degree;
		node* left; //for one district connected to the adjacent districts
		node* right; // moving into next district before checking its adj
		T * adj;
		int color;
		/**
			 * This is a node struct containing all pointers and public member variables
			 * and the constructor with default values
			 */
		node(T a, T b) :
				data(a), degree(1), left(nullptr), right(nullptr) {
			adj = new T[degree];
			adj[0] = b;
			color = -1;
		}
	}*root = nullptr, *traverse = nullptr;
	/**
		 * This function is the insert function of the graph of this class
		 */
	void ins(T a, T b) {
		ins(a, b, root);
		ins(b, a, root);

	}
	/**
		 * This function is the isEdge function of the graph of this class
		 */
	void isEdge(T a, T b) {
		isEdge(a, b, root);
	}
	/**
		 * This function is the traverseEdge function of the graph of this class
		 */
	template<typename fn>
	void traverseEdges(fn f) {
		traverseEdges(f, root);

	}
	/**
		 * This function is the traverseVertices function of the graph of this class
		 */
	template<typename fn>
	void traverseVertices(fn f) {
		traverseVertices(f, root);
	}
	/**
		 * This function is the solveCall function of the graph of this class
		 */
	void solveCall(T* list, int* degrees) {
		solve(list, degrees);
	}
	/**
		 * This function is the solve function of the graph of this class
		 */
	void solve(T* list, int* degrees, int &index) {
		solve(list, degrees, index, root);
	}
	/**
		 * This function is the assignData function of the graph of this class that calls assign
		 */
	void assignData(T data) {
		assign(data);
	}

private:
	/**
		 * This function is the insert function of the graph of this class of the private member function
		 */
	void ins(const T a, const T b, node* &p) {
		if (!p) {
			p = new node(a, b);
			nodes++;
			return;
		}
		if (a < p->data) {
			ins(a, b, p->left);
			return;
		}
		if (a > p->data) {
			ins(a, b, p->right);
			return;
		}
		if (a == p->data) {

			T array[p->degree];

			for (int i = 0; i < p->degree; i++) {
				array[i] = p->adj[i];
				if (p->adj[i] == b)
					return;
			}
			p->degree++;
			delete[] p->adj;
			p->adj = new T[p->degree];
			for (int i = 0; i < p->degree - 1; i++) {
				p->adj[i] = array[i];
			}
			p->adj[p->degree - 1] = b;
			return;
		}

	}
	/**
		 * This function is the assign function of the graph of this class
	 * This function is the traveerseEdges function
	 */
	template<typename fn>
	void traverseEdges(fn f, node* &p) {
		if (!p)
			return;
		else {
			traverseEdges(f, p->left);
			for (int i = 0; i < p->degree; i++) {
				f(p->data, p->adj[i]);
			}
			traverseEdges(f, p->right);
		}
	}
	/**
			 * This function is the assign function of the graph of this class
		 * This function is the traveerseVertices function
		 */
	template<typename fn>
	void traverseVertices(fn f, node* &p) {
		if (!p)
			return;
		else {
			traverseVertices(f, p->left);
			f(p->data);
			traverseVertices(f, p->right);
		}
	}
	/**
		 * This function is the solve function of the graph of this class to solve the graph coloring
		 */
	void solve(T* list, int* degrees) {
		int index = 0;
		solve(list, degrees, index, root);
		index++;
	}
	/**
		 * This function is the solve function of the graph of this class uses four variables
		 */
	void solve(T* list, int* degrees, int &index, node* p) {
		if (!p)
			return;
		else {
			solve(list, degrees, index, p->left);
			list[index] = p->data;
			degrees[index] = p->degree;
			index++;
			solve(list, degrees, index, p->right);
		}
	}
	/**
		 * This function is the assign function of the graph of this class retrurbs the assign function
		 */
	int assign(T data) {
		return assign(data, root);
	}
	/**
		 * This function is the assign function of the graph of this class have two data with a node
		 */
	int assign(T data, node* p) {
		int color = 0;
		assign(data, p->left);
		if (p->data == data) {
			assign(data, root, p->adj, p->degree, color);
			p->color = color;
			return color;
		}
		assign(data, p->right);
		return 0;
	}
	/**
		 * This function is the assign function of the graph of this class assgins the color in each district
		 */
	int assign(T data, node* p, T* adj, int degree, int &color) {
		if (!p)
			return -1;
		else {
			assign(data, p->left, adj, degree, color);
			for (int i = 0; i < degree; i++) {
				if (adj[i] == p->data) {
					if (p->color == color)
						color++;
				}
			}
			assign(data, p->right, adj, degree, color);

		}
		return color;
	}

};

//solution class for the color graph
/**
	 * This is the solution class that contains provate and public member variables and functions
	 */
template<typename T>
class solution {
public:
	T* list;
	int* degrees;
	int* colours;
	int nodes;
	//graph<T> gr;
	/**
		 * This the constructor of the solution class which assigns the private menmber variables
		 */
	solution(graph<T> g) {
		list = new T[g.nodes];
		degrees = new int[g.nodes];
		g.traverse = g.root;
		colours = new int[g.nodes];
		nodes = g.nodes;


	} // TODO: Color all nodes using Welsh-Powell algorithm
	/**
		 * This function is the color function of the graph of this class that outputs the district with colors
		 */
	unsigned color(const T a) const {
	/*	//int index = 0;
		for (int i = 0; i < nodes; i++) {
			if (a == list[i])
				 colours[i];

		}*/
		return 2;
	} // TODO: return color index number.
};

