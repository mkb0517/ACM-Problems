/*
//============================================================================
// Name        : p01.h
// Author      : Joshua Parep
// Version     :
 * Created on  : Jan 19, 2016
// Copyright   : No copy right, but do not copy from others
// Description : Matrix and Vector Multiplication
//============================================================================
 */

/**
 * class vec has vector list of 4 variavles of type T
 */
template <typename T>
class vec {
   T vecList[4];
public:
   //a default constructor to initialize values to 0,0 0,1
  vec(): vecList{0,0,0,1}{}
  /**
   *  constructor takes 4 parameters for initialization of the array
   */
  vec(T a1,T a2,T a3,T a4): vecList{a1,a2,a3,a4}{}
  T &operator[](int i){
	  return vecList[i];
  }
  T operator[](int i) const {
	  /**
	   * returns the variables from the list
	   */
    return vecList[i];
  }
  template <class os>
  friend os &operator<<(os &out,const vec<T> a) {
	  /**
	   * friend operator access the class variables and return array list
	   */
	  for(int i = 0; i < 4; i++){
    out << a[i];
	  }
    return out;
  }
};
template <typename T>
class mat {
  T a[4][4];// declare 4x4 dimensional array a
public:
  //default constructor and constructors to take
  // 16 parameters, a00, a01,..., a10,a11,…etc. through a33 to initialize a
  // 1 parameter x to initialize the diagonal values a[0][0], a[1][1], a[2][2], a[3][3]. All others 0
  // The default constructor should initialize it the same as passing 1 to initialize a diagonal
 mat(): a{1,0,0,0,
          0,1,0,0,
          0,0,1,0,
          0,0,0,1}{}

 mat(T x): a{x,0,0,0,
	         0,x,0,0,
			 0,0,x,0,
			 0,0,0,x}{}

 mat(T sx,T pz,T ny,T tx,T nz,T sy,T px,T ty,T py,T nx,T sz,T tz, T b,T c,T d,T e): a{
	 sx,pz,ny,tx,
	 nz,sy,px,ty,
	 py,nx,sz,tz,
	 b,c,d,e}{}

  T *operator[](int i) {
    /**
     * type T operator is pointing to the variable and returning it
     */
    return a[i];
  }
  T const *operator[](int i) const {
	  /**
	   *operator is pointing to the constant variable and returning it
	   */
    return a[i];
  }
  /**
   * multiply the matrix values and return it
   */
  mat<T> operator*(const mat<T> &x) const {
    mat<T> y{0};
    for(int i = 0; i < 4; i++){
    	for(int j = 0; j < 4; j++){
    		for(int n = 0; n < 4; n++){
    			y[i][j] += a[i][n] * x[n][j];
    		}
    	}
    }
    return y;
  }
  /**
   * multiply vector vales and return it
   */
  vec<T> operator*(const vec<T> &x) const {
    vec<T> y;
    for(int i = 0; i < 4; i++){
    	for(int j =0; j<4; j++){
    	  y[i] += a[i][j]*x[j];
    }
    }
    return y;
  }
  template <class os>
  /**
   * friend operator access the matrix values and return it
   */
  friend os &operator<<(os &out,mat<T> a) {
    for(int i = 0; i < 4; i++){
    	for(int j = 0; j < 4; j++){
    	out << a[i][j];
    	}
    }
    return out;
  }
};
