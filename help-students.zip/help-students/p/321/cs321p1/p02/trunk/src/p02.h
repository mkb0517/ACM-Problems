/**
 * p02.h
 *  Created on: Jan 25, 2016
 *      Author: Joshua Parep
 */
template<typename T=int>
/**
 * This class has private member functions and node.
 */
class list {
public:
	/**
	 * node struct contains the member variables and default and overloaded constructor
	 */
  struct node {
	  T data;
	     node *next;
/**
 * overloaded constructor for node struct
 */
	     node(T data, node*next = nullptr): data(data), next(next){}
	     ;
	     /**
	      * this is destructor for the node struct
	      */
	     ~node(){}
  };
  template<typename fn>
  /**
   * call f(node) for each node in the list
   */
  void inorder(fn f) {
	inorder(f, root);
  }
  /**
   * insert a node containing value n
   */
  void ins( T n) {
     ins(n,root);
  }
  /**
   * delete a node containing n from the link list
   */
  void del( T n) {
     del(n, root);
  }
  /**
   * delete all nodes from the link list
   */
  void del(){
    delAll(root);
  }

protected:
    node* root;
    template<typename fn>
 /**
  * call f(node) for each node in the list
  */
  	   void inorder(fn f, node* &p) {
           if(!p) return;
           else
        	   f(p);
        	  inorder(f, p->next);
  }
/**
 * insert a node containing n from the link list
 */
	void ins(T n, node* &p){
		 if(!p){
		     p = new node(n);
		     return;
		 }
		 if(n < p->data){
			p = new node(n,p);
			 return;
		 }
		 if (n > p->data){
			 ins(n,p->next);
			 return;
		 }
	}
/**
 * delete a node containing n
 */
	void del( T n, node* &p) {
		  if(!p) return;
		  if(n < p->data)return;
		  if(n == p->data){
			  node* temp;
			  temp = p->next;
			  delete p;
			  p = temp;
			  return;
		  }
		  if(n > p->data){
			  del(n, p->next);
		  }
	  }
/**
 * delete all nodes in the link list
 */
	  void delAll(node* &p){
		 if(!p) return;
		  delAll(p->next);
		  delete p;
		  p = nullptr;
		  return;
	  }
public:
/**
 * public for list class contains the
 */
	  list(){
		  root = nullptr;

	  }

};
