/**
 * p04.h
 *
 *      @author: Joshua Parep
 */
/**
 * this is a tree class and it has private and public member functions.
 * The computers are done in the private member functions and they called in the public
 * member functions.
 */
template<typename T = int>
class tree {
public:
/**
 * This is a struct class nested inside tree class. It member functions of left and
 * right node  of the tree and they are set to null pointer.
 */
	struct node {
		T data;
		node *left, *right;
/**
* this is a default constructor function that sets two member functions
* left and right to null pointer as default.
*/
			node(T data) :data(data){
				left = nullptr;
				right = nullptr;
			}
	};
	/**
	 *This function call inoder(f), which call f(node) for each node in the list.
	 */
	template<typename fn>
		void inorder(fn f) {
		inorder(f, root);
	}
	/**
	 *This function call preorder(f), which call f(node) for each node in the list.
	 */
	template<typename fn>
		void preorder(fn f) {
		preorder(f, root);
	}
	/**
	 *This function call postorder(f), which call f(node) for each node in the list.
	 */
	template<typename fn>
		void postorder(fn f) {
		postorder(f, root);
	}
	/**
	 * This function calls ins(n), which inserts the nodes into the tree list.
	 */
	void ins(T n) {
		ins(n,root);
	}
	/**
	 * This function calls del(n), which delete a node containing n in the list.
	 */
	void del(T n) {
		del(n,root);
	}
	/**
	 * This function calls del(), which delete all nodes in the tree list.
	 */
	void del() {
		del(root);
	}
	/**
	 * This function calls delMin(), which delete the minimum value on the right side of the tree.
	 */
	void delMin(){
		delMax(root);
	}

protected:
	node* root;
	/**
	 *This function call f(node) for each node in the list in order.
	 */
	template<typename fn>
	void inorder(fn f, node* &p) {
		if(!p)return;
		else{
			  inorder(f,p->left);
			  f(p);
			  inorder(f,p->right);
		}
	}
	/**
	 *This function call f(node) for each node in the list in pre order.
	 */
	template<typename fn>
	void preorder(fn f, node* &p) {
		if(!p)return;
		else{
        f(p);
		preorder(f,p->left);
		preorder(f,p->right);
		}
	}
	/**
	 * This function call f(node) for each node in the list in post order.
	 */
	template<typename fn>
	void postorder(fn f, node* &p) {

		if(!p)return;
		else{
		postorder(f,p->left);
		postorder(f,p->right);
         f(p);
		}
	}
	/**
	* This function inserts a node containing n into the tree list.
	*/
	void ins(T n, node* &p) {
		if(!p){
			p = new node(n);
			return;
		}
		else if(n < p->data){
			ins(n, p->left);
			return;
		}
		else if(n > p->data){
			ins(n, p->right);
			return;
		}
		else
			return;
	}
	/**
	 * This function delete a node containing n in the tree.
	 */
	void del(T n, node* &p) {
		if(!p) return;
		else if (n < p->data){
			del(n, p->left);
			return;
		}
		else if (n > p->data){
			del(n, p->right);
			return;
		}
		else if (n == p->data)
		{
			if (!p->left && !p->right){
			 //to prevent memory lick
				delete p;
				p = 0;
			}
			else if (!p->left){
				node* temp = p;
				  p = p->right;
				delete temp;
				return;
			}
			else if (!p->right){
				node* temp = p;
				  p = p->left;
			    delete temp;
			    return;
				}
			else
		  delMin(p->right,p->data);
		}
	}
	/**
	 * This function deletes all the nodes in tree.
	 */
	void del(node* &p) {
	if(!p) return;
			  del(p->right);
			  del(p->left);
			  delete p;
			  p = nullptr;
			  return;
	}
	/**
	 * This function deletes the minimum value from the tree.
	 */
	void delMin(node* &p, T &n){
		if(!p)return;

		while (p->left){
			p = p->left;
		}
		n = p->data;

		node* doomed = p;
		p = p->right;
		delete doomed;
	}

public:
	/**
	 * This is a default constructor function for tree class.
	 * It assign the member variable, root, to null pointer as a default value.
	 */
	tree(){
		root = nullptr;
	}
};
