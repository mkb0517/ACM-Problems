//============================================================================
// Name        : p08.cpp
// Author      :Joshua Parep
// Version     : 0
// Description : The game of NIM, human vs robot
//============================================================================
#define _hypot hypot // bug workaround. To fix, upgrade G++ by installing http://win-builds.org/1.5.0/win-builds-1.5.0.exe

#include <iostream> // cin, cout, instream, ostream, endl
#include <vector> // vector
#include <sstream> // istringstream
#include <iomanip> // setw
#include <algorithm> // sort, find_if, remove_if
#include <cmath>

using namespace std;
/**
 *Cluster class contains protected member variables of item and amount
 *and the class functions return item and the amount
 */
class Cluster { // how many of which item together
protected:
	char item;
	int amount;
public:
	Cluster(char item = '*', int amount = 0) :
			item(item), amount(amount) {
	}
	friend ostream &operator<<(ostream &out, const Cluster &x) {
		out << string(x.amount, x.item);
		return out;
	}
	friend istream &operator>>(istream &in, Cluster &x) {
		in >> x.item;
		for (x.amount = 1; in.peek() == x.item; x.amount++) {
			in >> x.item;
		}
		return in;
	}

	int getAmount() const {
		return amount;
	}

	char getItem() const {
		return item;
	}

	friend class Game;
};
/*
 * Row class is the subclass of Cluster class
 *  and it returns amount and the shapes
 */
class Row: public Cluster {
public:
	friend ostream &operator<<(ostream &out, const Row &x) {
		return out << setw(2) << x.amount << ": " << (Cluster) x;
	}
};
/*
 * Selection class is the subclass of Cluster class which
 * shows the player's move
 */
class Selection: public Cluster {
public:
	Selection() :
			Cluster('$', 5) {
	}
	Selection(char item, int amount) :
			Cluster(item, amount) {
	}
	friend ostream &operator<<(ostream &out, const Selection &selection) {
		return out << selection.amount << " from " << selection.item
				<< " group.";
	}
};
/*
 * Game class removes empty rows and also it sorts all rows
 * according to the ordering given by the less-than function
 */
class Game {
	vector<Row> rows;
public:
	vector<Row> &getRows() {
		return rows;
	}
	enum state_t {
		UNINITIALIZED, READY, OVER, BOGUS,
	} state;
	state_t fixup() {
		// Delete all rows that are empty (their amount is zero).
		// remove_if does not erase the elements, but moves them to the end
		// and points to where they were removed so they can be erased.
		// Use erase to remove the elements from that point to the end
		rows.erase(remove_if(rows.begin(), rows.end(), // target those items in  this range that satisfy the function.
				[](const Row &r) {return !r.amount;}), // The function defined here tells when amount is zero
		rows.end());
		if (rows.empty()) {
			return state = OVER;
		}
		// Sort all rows according to the ordering given by the less-than function
		sort(rows.begin(), rows.end(), [](const Row &a,const Row &b) { // the less-than function is defined here
					if (a.amount<b.amount) return true;// first sort on the amount
					if (a.amount>b.amount) return false;
					return a.item<b.item;}); // if the amount is equal, sort on the item next
		if (rows[0].amount < 0) {
			return state = BOGUS;
		}
		return state;
	}
	Game(string setup = "#######$$$%%%%%%") {
		istringstream in(setup);
		in >> *this;
		fixup();
	}
	state_t operator-=(Selection remove) {
		{
			// i is an iterator object. An iterator is a class that is designed to act a lot like a pointer
			auto i = find_if(rows.begin(), rows.end(),
					[remove](const Row &r) {return r.item==remove.item;});
			if (i == rows.end()) {
				return state = BOGUS;
			}
			i->amount -= remove.amount;
		}
		return fixup();
	}
	friend istream &operator>>(istream &in, Game &g) {
		Row r;
		g.state = UNINITIALIZED;
		while (in >> r) {
			g.rows.push_back(r);
			g.state = READY;
		}
		return in;
	}
	friend ostream &operator<<(ostream &out, const Game &g) {
		for (Row row : g.rows) {
			out << row << endl;
		}
		return out;
	}
};
/*
 * Player class returns player's move and ask
 * next players move
 */
class Player {
private:
	string name;
public:
	Player(const string &name) :
			name(name) {
	}
	friend ostream &operator<<(ostream &out, const Player *player) {
		return out << player->name;
	}
	virtual Selection move()=0;
	virtual ~Player() = default;
};
/*
 * Simple robotic player class is the subclass of player class
 * It returns simple robotic players move
 */
class SimpleRoboticPlayer: public Player {
	Game &game;
	static string nextName() {
		static int n = 0;
		if (n++)
			return "Simple Robot Player #" + n;
		return "Simple Robot Player";
	}
public:
	SimpleRoboticPlayer(Game &game, string name = nextName()) :
			Player(name), game(game) {
	}
	virtual Selection move() {
		return Selection(game.getRows()[0].getItem(), 1);
	}
};
/*
 * My player class will plays automatically
 *and can win against the SimpleRobotPlayer
 regardless of which player goes first.
 */
class MyRoboticPlayer: public Player {
	Game &game;
	static string nextName() {
		static int n = 0;
		if (n++)
			return "My Robotic Player #" + n;
		return "My Robotic Player";
	}
public:
	MyRoboticPlayer(Game &game, string name = nextName()) :
			Player(name), game(game) {
	}
	virtual Selection move() {
		Selection selection;

		for (unsigned int i = 0; i < game.getRows().size(); i++) {

			if (game.getRows()[i].getAmount() % 2 == 0)
				selection = Selection(game.getRows()[i].getItem(),game.getRows()[i].getAmount() );
			else if (game.getRows()[i].getAmount() % 3 == 2)
							selection = Selection(game.getRows()[i].getItem(), 2);

			else
				selection = Selection(game.getRows()[i].getItem(), 1);

		}
		return selection;
	}
};
/*
 * Human player class is the subclass of player class.
 * It ask human player to move and returns the result.
 */
class HumanPlayer: public Player {
	Game &game;
	static string nextName() {
		static int n = 0;
		cout << "Name of player #" << ++n << ": ";
		string result;
		cin >> result;
		return result;
	}
public:
	HumanPlayer(Game &game, string name = nextName()) :
			Player(name), game(game) {
	}

	virtual Selection move() {
		Selection selection;
		cout << "Enter items to remove:";
		cin >> selection;
		return selection;
	}
};
/*
 * This is the main function of the program which converts the subclass to the base class
 * and shows players move and the game state0
 */
int main() {
	Game game("***.....@@@@@####$$");
	// We must use pointers to avoid slicing, which would implicitly convert the subclass to the base class.
	vector<Player*> players = { new HumanPlayer(game),
			new MyRoboticPlayer(game) };

	for (;;) {
		for (auto player : players) {
			cout << game << player << ':' << endl;
			Selection selection = player->move();
			cout << "  Took " << selection << endl << endl;
			switch (game -= selection) {
			case Game::OVER:
				cout << player << " lost by taking the last item." << endl;
				return 0;
			case Game::BOGUS:
				cout << player << " lost by cheating" << endl;
				return 0;
			case Game::UNINITIALIZED:
				cout << "  Game is not set up" << endl;
				return 0;
			default:
				continue; // resume inner loop
			}
		}
	}
	return 0;
}
