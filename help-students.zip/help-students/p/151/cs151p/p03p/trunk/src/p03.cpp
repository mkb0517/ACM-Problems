//============================================================================
// Name        : p03.cpp
// Author      : Joshua Parep
// Version     :
// Copyright   : 
// Description : Translation Dictionary
/* This program translates Hawaiian words in English.
 * User is asked to input the Hawaiian words and the
 * it will define the word. If the word is not
 * in the list, then it will ask user to define it
 * and store the definition of the word in the list.
 */
//============================================================================
/*
 * Directive. Include map and string header files.
 */
#include <iostream>
#include<string>
#include<map>

using namespace std;
/*
 * Main function.
 * Asks user for the Hawaiian words and give definition.
 * If the word is not in the list, ask user for the
 * definition.
 */
int main() {
    string n, m;

    map<string, string> word;
    map<string, string>::iterator it;

    cout << "Welcome to Hawaiian word dictionary translation." << endl;
    cout << "Whenever you are done, press period (.)";
    cout << " key to exit the program" << endl;

    word["Aloha"] = "Hello";
    word["Mahalo"] = "Thank You";

    for (;;) {
        cout << endl;
        cout << "Please enter a Hawaiian word.";
        getline(cin, n);
        if (n == ".") break;

        if (word[n] == "") {
            cout << "What does " << n << " means? ";
            getline(cin, m);

            word[n] = m;

        } else {
            cout << word[n];
        }

    }
    cout << endl;
    cout << "You are exiting the program." << endl << endl;
    cout << "Aloha!" << endl;
    return 0;
}

