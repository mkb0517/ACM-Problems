//============================================================================
// Name        : p09.cpp
// Author      : Joshua Parep
// Version     :
// Description : NIM program using structured exceptions instead of status
//============================================================================
#define _hypot hypot // bug workaround. To fix, upgrade G++ by installing http://win-builds.org/1.5.0/win-builds-1.5.0.exe

#include <iostream>
#include <stdexcept>
#include <exception>
#include <vector> // vector
#include <sstream> // istringstream
#include <iomanip> // setw
#include <algorithm> // sort, find_if, remove_if
#include <cmath>

using namespace std;

/*
 * game exception class
 */
class GameException: public exception {
	const char *message = " lost by taking the last item.";
public:
	const char *what() {

		return message;
	}
};
/*
 * sub exception class for cheating
 */
class GameExceptionCheating: public GameException {
};
/*
 * sub exception class for cheating from a empty row
 */
class GameExceptionEmptyCheating : public GameException {
};

/**
 *Cluster class contains protected member variables of item and amount
 *and the class functions return item and the amount
 */
class Cluster { // how many of which item together
protected:
	char item;
	int amount;
public:
	Cluster(char item = '*', int amount = 0) :
			item(item), amount(amount) {
	}
	friend ostream &operator<<(ostream &out, const Cluster &x) {
		out << string(x.amount, x.item);
		return out;
	}
	friend istream &operator>>(istream &in, Cluster &x) {
		in >> x.item;
		for (x.amount = 1; in.peek() == x.item; x.amount++) {
			in >> x.item;
		}
		return in;
	}

	int getAmount() const {
		return amount;
	}

	char getItem() const {
		return item;
	}

	friend class Game;
};
/*
 * Row class is the subclass of Cluster class
 *  and it returns amount and the shapes
 */
class Row: public Cluster {
public:
	friend ostream &operator<<(ostream &out, const Row &x) {
		return out << setw(2) << x.amount << ": " << (Cluster) x;
	}
};
/*
 * Selection class is the subclass of Cluster class which
 * shows the player's move
 */
class Selection: public Cluster {
public:
	Selection() :
			Cluster('$', 5) {
	}
	Selection(char item, int amount) :
			Cluster(item, amount) {
	}
	friend ostream &operator<<(ostream &out, const Selection &selection) {
		return out << selection.amount << " from " << selection.item
				<< " group.";
	}
};
/*
 * Game class removes empty rows and also it sorts all rows
 * according to the ordering given by the less-than function
 */
class Game {
	vector<Row> rows;
public:
	vector<Row> &getRows() {
		return rows;
	}

	bool fixup() {

		// Delete all rows that are empty (their amount is zero).
		// remove_if does not erase the elements, but moves them to the end
		// and points to where they were removed so they can be erased.
		// Use erase to remove the elements from that point to the end
		rows.erase(remove_if(rows.begin(), rows.end(), // target those items in  this range that satisfy the function.
				[](const Row &r) {return !r.amount;}), // The function defined here tells when amount is zero
		rows.end());
		if (rows.empty()) {
			throw GameException();   //game is over becasue someone took last item.
		}
		// Sort all rows according to the ordering given by the less-than function
		sort(rows.begin(), rows.end(), [](const Row &a,const Row &b) { // the less-than function is defined here
					if (a.amount<b.amount) return true;// first sort on the amount
					if (a.amount>b.amount) return false;
					return a.item<b.item;}); // if the amount is equal, sort on the item next
		if (rows[0].amount < 0) {
			throw  GameExceptionCheating();                     //someone is cheating
		}
		return true;

	}
	Game(string setup = "#######$$$%%%%%%") {
		istringstream in(setup);
		in >> *this;
		fixup();

	}
	bool operator-=(Selection remove) {
		{
			// i is an iterator object. An iterator is a class that is designed to act a lot like a pointer
			auto i = find_if(rows.begin(), rows.end(),
					[remove](const Row &r) {return r.item==remove.item;});
			if (i == rows.end()) {
				throw GameExceptionEmptyCheating();
			}
			i->amount -= remove.amount;
		}
		return fixup();
	}
	friend istream &operator>>(istream &in, Game &g) {
		Row r;

		while (in >> r) {
			g.rows.push_back(r);

		}
		return in;
	}
	friend ostream &operator<<(ostream &out, const Game &g) {
		for (Row row : g.rows) {
			out << row << endl;
		}
		return out;
	}
};
/*
 * Player class returns player's move and ask
 * next players move
 */
class Player {
private:
	string name;
public:
	Player(const string &name) :
			name(name) {
	}
	friend ostream &operator<<(ostream &out, const Player *player) {
		return out << player->name;
	}
	virtual Selection move()=0;
	virtual ~Player() = default;
};
/*
 * Simple robotic player class is the subclass of player class
 * It returns simple robotic players move
 */
class SimpleRoboticPlayer: public Player {
	Game &game;
	static string nextName() {
		static int n = 0;
		if (n++)
			return "Simple Robot Player #" + n;
		return "Simple Robot Player";
	}
public:
	SimpleRoboticPlayer(Game &game, string name = nextName()) :
			Player(name), game(game) {
	}
	virtual Selection move() {
		return Selection(game.getRows()[0].getItem(), 1);
	}
};
/*
 * My player class will plays automatically
 *and can win against the SimpleRobotPlayer
 regardless of which player goes first.
 */
class MyRoboticPlayer: public Player {
	Game &game;
	static string nextName() {
		static int n = 0;
		if (n++)
			return "My Robotic Player #" + n;
		return "My Robotic Player";
	}
public:
	MyRoboticPlayer(Game &game, string name = nextName()) :
			Player(name), game(game) {
	}
	virtual Selection move() {
		Selection selection;

		for (unsigned int i = 0; i < game.getRows().size(); i++) {

			if (game.getRows()[i].getAmount() % 2 == 0)
				selection = Selection(game.getRows()[i].getItem(),
						game.getRows()[i].getAmount() - 1);

			//else if (game.getRows()[i].getAmount() % 3 == 2)
			//selection = Selection(game.getRows()[i].getItem(), 1);

			else
				selection = Selection(game.getRows()[i].getItem(), 1);

		}
		return selection;
	}
};
/*
 * Human player class is the subclass of player class.
 * It ask human player to move and returns the result.
 */
class HumanPlayer: public Player {
	Game &game;
	static string nextName() {
		static int n = 0;
		cout << "Name of player #" << ++n << ": ";
		string result;
		cin >> result;
		return result;
	}
public:
	HumanPlayer(Game &game, string name = nextName()) :
			Player(name), game(game) {
	}

	virtual Selection move() {
		Selection selection;
		cout << "Enter items to remove:";
		cin >> selection;
		return selection;
	}
};


/*
 * main function of the program that calls the throw function and contains try and catch
 */
int main() {
	try {
		Game game("***.....@@@@@####$$");
		// We must use pointers to avoid slicing, which would implicitly convert the subclass to the base class.
		vector<Player*> players = { new HumanPlayer(game), new MyRoboticPlayer(
				game) };
		for (;;) {
			for (auto player : players) {
				cout << game << player << ':' << endl;
				Selection selection = player->move();
				cout << "  Took " << selection << endl << endl;

				if (game -= selection) {
					continue;
				} else{
					return 0;
				}

			}
		}

	} catch(GameExceptionCheating &n){
		cout <<" lost by cheating." << endl;
	}catch (GameExceptionEmptyCheating &m){
		cout <<" lost by taking item from a empty row." <<endl;
	} catch (GameException &e) {
			cout << "  " << e.what() << endl;
	} catch (...) {
		cerr << "I don't know how to handle the exception that occurred.";

	}
	return 0;
}

