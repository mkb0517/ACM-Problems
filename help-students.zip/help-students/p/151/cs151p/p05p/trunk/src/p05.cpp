//============================================================================
// Name        : Lab p05.cpp
// Author      :Joshua Parep
// Description : Introducing pointers with the game of NIM
//============================================================================
#include <iostream>
#include <cctype>
#include <string>
#include <sstream>
#include <map>
#include <cstdlib>
#include <locale>

using namespace std;

/**
*
*/
struct Row {
	string name;
	int count;
	char shape;
};

/**
*class containing data variable functions
*/
class Selection {
	Row *p;
	int amount;
public:
	Selection(Row* var, int amt) :p(var), amount(amt) {}
	~Selection() {};
	int getAmount()const {
		return amount;
	}
	void setAmount(int amount)
	{
		this->amount = amount;
	}
	Row* getp()const {
		return p;
	}
	int operator --() {
		return p->count -= amount;
	}
};

/**
*Take turns. Each time this function altering between player 1 and player 2.
*/
int turn() {
	static int player = 2;
	player = (player == 1 ? 2 : 1);
	return player;
}
/**
* this function creates same shapes many times.
* */
string numShapes(int n, char charShape) {
	string resultShape;

	for (int i = 0; i < n; i++)
		resultShape += charShape;
	return resultShape;
}

void show(Row *p) {

	for (; '\0' != p->shape; p++) {
		if (p->count == 1) {

			cout << p->name << " : ";
			cout << numShapes(p->count, (p->shape));
			cout << " " << p->count << " " << endl;
		}
		else {
			if(p->count >=0)
					cout << p->name << "s : ";
					cout << numShapes(p->count, (p->shape));
					cout << p->count << " " << endl;
		}
	}
}
/*
This function changes the upper case string into low case.
*/
string low(string word) {

	string lower = "";
	locale loc;

	for (unsigned int i = 0; i < word.length(); i++) {

		lower += tolower(word[i], loc);
	}
	return lower;
}
/*
This function removes s at the end of name
*/
string removeS(string str) {

	int i;
	i = str.length() - 1;

	if (str[i] == 's')
		str.erase(i, 1);
	return str;
}

/**
*This function ask players move.
*/
Selection move(Row *p) {
	string row;
	int n;
	bool good=false;
	string nam;
	Row *q;
	q=p;
	cout << " Which group?";
	cin >> row;
	row = low(row);

	row = removeS(row);

	while (q->name!="")
	{
		nam = q->name;

		if (nam==row)
		{
			good=true;
		}
		q++;

	}

	if (good == true)
	{

		cout << " How many " << row << "s? ";
		cin >> n;

		cout << n << " from row " << row << "." << endl;


		for (; p->shape != '\0'; p++) {

			if (row == p->name) {
				p->count -= n;
			}
			if (n < 1 || p->count < 0) {
						cout << endl;
						cout << "Invalid move; Disqualified for cheating." << endl << endl;
						cout << "Player: " << turn() << " wins!" << endl;
					exit(0);
			}
		}
	}
	else {
		cout << endl;
		cout << "You are disqualified for cheating (by making an invalid move)" << endl << endl;
		cout << "Player: " << turn() << " wins!" << endl;
		exit(0);

	}

	//}
	Selection selected(p, n);
	return selected;
}
/**
*add the count to the sum and increment the pointer and
*return total of count values for all rows
*/
int total(Row *p) {
	int sum = 0;
	while (p->shape) {
		sum += p++->count;
	}
	return sum;
}

/**
*Main function.
*/
int main() {
	Row a[] = {
		{ "dollar", 3, '$' },
		{ "star", 5, '*' },
		{ "dot", 6, '.' },
		{ "wave", 5, '~' },
		{ "", 0, '\0' },
	};
	for (;;) {

		show(a);
		cout << endl << "Player " << turn()<<" :";
		if (!total(a)) {
			cout << " wins!";
			break;
		};
		Selection selected = move(a);
		--selected;
	}
	return 0;
}
