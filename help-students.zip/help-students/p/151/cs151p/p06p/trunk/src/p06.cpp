//============================================================================
// Name        : p06.cpp
// Author      : Joshua Parep
// Version     :
// Copyright   :
// Description : Dictionary of Hawaiian Translations
//============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <map>

using namespace std;
/**
 * This function reads data from the string and store it to the dictionary
 */
void readFromString(map<string, string>& dic) {
    std::stringstream ss;
    ss << "ekahi one" << endl << "elua two" << endl << "ekolu three" << endl;
    string word;
    while (ss >> word >> ws) {
        getline(ss, dic[word]);
    }
}
/**
 * It reads data from the data text file and stored it into the dictionary.
 */
void readFromFile(map<string, string>& dic) {

    string word;
    ifstream in("data.txt");
    if (in.fail()) {
        cout << "File error" << endl;
    }

    else {
        while (in >> word >> ws) {
            getline(in, dic[word]);
        }
    }
    in.close();
}
/**
 * This function writes data into the data txt file and store it into the dictionary
 */
void writeToFile(const map<string, string>& dic) {
    ofstream out("data.txt");
    if (out.is_open()) {
        for (pair<string, string> def : dic) {
            out << def.first << '\t' << def.second << endl;
        }
    }
    out.close();
}
/**
 * This function list gets the meaning of all the words from the dic and displays it.
 */
void listDict(const map<string, string>& dic) {
    for (pair<string, string> def : dic) {
        cout << '"' << def.first << "\" means \"" << def.second << '"' << endl;
    }
}
/**
 * This funct6ion add data into the dictionary list
 */
void addToDict(map<string, string>& dic) {
    string word;
    cout << "New word: " << flush;
    while (cin >> word) {

        if (word == ".") {
            dic.clear();
            break;
        }

        else {
            if (dic[word] == "") {
                cout << "New definition: " << flush;
                cin >> ws;
                getline(cin, dic[word]);
                break;

            } else {

                cout << "New definition: " << flush;
                cin >> ws;
                getline(cin, dic[word]);
                if (dic[word] == ".") {
                    dic.erase(word);
                    break;
                }
            }

        }

        listDict(dic);
        cout << "New word: " << flush;
    }
}

/**
 * Main function of the program
 */
auto main() -> int {
    map<string, string> dic;

    readFromString(dic);
    readFromFile(dic);
    listDict(dic);
    addToDict(dic);
    writeToFile(dic);

    cout << "\nMahalo." << endl << endl;

    return 0;
}
