//============================================================================
// Name: Joshua Parep       : p00.cpp
// Author      : 
// Version     :
// Copyright   : 
// Description : The game of NIM
//     Players must remove at least one star from one row each turn.
//     To win, a player must always leave at least one star for the opponent.
//============================================================================
/**
 * directives
*/
#include <iostream>
#include <cctype>

using namespace std;

/**
 * Take turns. Each time this function executes, it will be alternating between 1 and i. Set players to 2.
 * Switch players, and return player.
 */
int turn()
{
	static int player=2;
	player = (player==1?2:1);
	return player;
}
/**
 * void star function out puts the n asterisks to represent number of elements in each rows.
 */
void stars(int n)
{
	for (int i=0;i<n;i++) cout << '*';
}

/**
 * function showing the characters. Star function is called to show the number of stars in the rows.
 */
void show(int a, int b, int c)
{

	cout << "A:";
	stars(a);
	cout << a << endl;
	cout << "B:";
	stars(b);
	cout << b << endl;
	cout << "C:";
	stars(c);
	cout << c << endl;

}
/**
 * function asking the player's moves. Use switch function to remove n stars from the rows.
 */
void move(int &a, int &b, int &c)
{

		char row;

	int n;

	cout << "Which row?";
	cin >> row;
	cout << "How many from row " << row << "?";
	cin >> n;
	cout << n << " from row " << row << "." << endl;
	switch (toupper(row))
	{
	case 'A':
		a -= n;
		break;
	case 'B':
		b -= n;
		break;
	case 'C':
		c -= n;
		break;
	default:
		n = 0;
	}
	if (n < 1 || a < 0 || b < 0 || c < 0)
	{
		cout << "You are disqualified for cheating (by making an invalid move)."
				<< endl;
		a=0; b=0; c=0;
	}

}
/**
 * main function. Show and move functions are also called in the main function.
 */

int main() {
	int a=3,b=5,c=7;
	do{
		cout << "Player: " << turn();
		cout <<endl;
		if (a+b+c==0)
		cout << "wins!\n";
		show(a, b, c);
		move(a, b, c);
	}while(a+b+c != 0);
	cout << "Player: " << turn();
	if (a+b+c==0)
	cout << " wins!\n";


	return 0;
}
