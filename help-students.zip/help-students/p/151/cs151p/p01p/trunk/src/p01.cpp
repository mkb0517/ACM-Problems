//============================================================================
// Name :      : p01.cpp
// Author      : Joshua Parep
// Version     :
// Copyright   :
// Description : The game of NIM
//     Players must remove at least one star from one row each turn.
//     To win, a player must always leave at least one star for the opponent.
//============================================================================
/**
 * Directives
 */
#include <iostream>
#include <cctype>
using namespace std;

/**
 * Take turns. Each time this function altering between player 1 and player 2.
 */
int turn() {
	static int player = 2;
	player = (player == 1 ? 2 : 1);
	return player;
}

/**
 * Void star function increment the stars.
 */
void stars(int n) {
	for (int i = 0; i < n; i++)
		cout << '*';
}

/**
 * Void show function shows the stars in each row. Star function is called here.
 */
void show(int a[]) {
	cout << "A:";
	stars(a[0]);
	cout << a[0] << endl;
	cout << "B:";
	stars(a[1]);
	cout << a[1] << endl;
	cout << "C:";
	stars(a[2]);
	cout << a[2] << endl;
}

/**
 * Void move function ask the move for the next player and displays it.
 */
void move(int a[]) {
	char row;
	int n;
	cout << "Which row?";
	cin >> row;
	cout << "How many from row " << row << "?";
	cin >> n;
	cout << n << " from row " << row << "." << endl;
	switch (toupper(row)) {
	case 'A':
		a[0] -= n;
		break;
	case 'B':
		a[1] -= n;
		break;
	case 'C':
		a[2] -= n;
		break;
	default:
		n = 0;
	}
	if (n < 1 || a[0] < 0 || a[1] < 0 || a[2] < 0) {
		cout << "You are disqualified for cheating (by making an invalid move)."
				<< endl;
		a[0] = 0;
		a[1] = 0;
		a[2] = 0;
	}
}

/**
 * Main function
 */
int main() {
	int a[3] = { 3, 5, 7 };
	do {
		cout << "Player: " << turn();
		if (a[0] + a[1] + a[2] == 0)
			cout << "wins!";
		cout << endl;
		show(a);
		move(a);
	} while (a[0] + a[1] + a[2] != 0);
	cout << endl;
	cout << "Player: " << turn();
	if (a[0] + a[1] + a[2] == 0)
		cout << " wins!";
	cout << endl;

	return 0;
}
