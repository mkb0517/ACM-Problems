//============================================================================
// Name        : p07.cpp
// Author      :Joshua Parep
// Version     :
// Copyright   :
// Description : Hello World in C++, Ansi-style
//============================================================================
#include <iostream>
#include <fstream>
#include <iomanip>
#include <ios>

using namespace std;
/**
 *  Recursion binary function
 */

void binary(char byte, int numbits = 8) {
	if (byte == '\0')
		return;
	if (numbits > 0) {
		cout << bool(byte & (1 << (numbits - 1)));
		binary(byte, numbits - 1);
	} else
		return;
}
/**
 *  Main function of the program
 */

int main(int argc, char *argv[]) {

	if (argc < 2) {
		cerr << "Usage:  " << argv[0] << " filename" << endl;
		return 1;
	}

	else {
		for (int i = 1; i < argc; i++) {
			ifstream inFile;
			inFile.open(argv[i], ios::binary | ios::in);

			if (!inFile.good()) {
				cout << "File error" << endl;
			}

			else {
				char ch;
				while (inFile.get(ch)) {
					binary(ch);
					cout << setw(3);
				}
			}
			inFile.close();
		}
	}
	return 0;
}

