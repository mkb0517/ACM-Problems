//============================================================================
// Name        : p02.cpp
// Author      :Joshua Parep
// Version     :
// Copyright   :
// Description : The game of NIM
//     Players must remove at least one star from one row each turn.
//     To win, a player must always leave at least one star for the opponent.
//============================================================================
/**
 * Directives
 */
#include <iostream>
#include <cctype>
#include <string>
#include <cstdlib>
#include <sstream>
#include <locale>

using namespace std;

/*
 struct Row containing three data variables
 */
struct Row {

	string name;
	int count;
	char shape;

};
/*
 function proyotype
 */
int turn();
string shapes(int, char);
void show(Row row[]);
void move(Row row[]);
bool check(Row row[]);
/**
 * Take turns. Each time this function altering between player 1 and player 2.
 */
int turn() {
	static int player = 2;
	player = (player == 1 ? 2 : 1);
	return player;
}

/**
 * this function creates same shapes many times.
 * */
string shapes(int n, char charShape) {
	string resultShape;

	for (int i = 0; i < n; i++)
		resultShape += charShape;
	return resultShape;
}
/**
 * This function displays  different shape in each group.
 */
void show(Row row[]) {

	for (int i = 0; '\0' != row[i].shape; i++) {
		if (row[i].count == 1) {
			cout << row[i].count << " ";
			cout << row[i].name << " : ";
			cout << shapes(row[i].count, (row[i].shape)) << endl;
		} else if (row[i].count > 1) {
			cout << row[i].count << " ";
			cout << row[i].name << "s : ";
			cout << shapes(row[i].count, (row[i].shape)) << endl;
		}
	}
}
/*
 This function changes the upper case string into low case.
 */
string low(string word) {

	string lower = "";
	locale loc;

	for (unsigned int i = 0; i < word.length(); i++) {

		lower += tolower(word[i], loc);
	}
	return lower;
}
/*
 This function removes s at the end of name
 */
string removeS(string str) {

	int i;
	i = str.length() - 1;

	if (str[i] == 's')
		str.erase(i, 1);
	return str;
}
/*
 This function ask players move
 */
void move(Row row[]) {
	string whichRow;
	int n;

	cout << "Which group?";
	cin >> whichRow;
	whichRow = low(whichRow);

	whichRow = removeS(whichRow);

	if(whichRow =="dollar" ||whichRow=="star" ||whichRow == "wave" || whichRow== "dot"){

	cout << " How many " << whichRow << "s? ";
	cin >> n;

	cout << n << " from row " << whichRow << "." << endl;

	for (int i = 0; row[i].shape != '\0'; i++) {

		if (whichRow == row[i].name) {
			row[i].count -= n;
		}
	}
    }
    else{
    	cout <<endl;
    	cout << "You are disqualified for cheating (by making an invalid move)" << endl << endl;
    			cout << "Player: " << turn() << " wins!" << endl;
    			exit(0);
    }

	for (int i = 0; row[i].shape != '\0'; i++) {
		if (n < 1 || row[i].count < 0) {
			cout << endl;
			cout
					<< "You are disqualified for cheating (by making an invalid move)"
					<< endl << endl;
			cout << "Player: " << turn() << " wins!" << endl;
			exit(0);
		}
	}
}
/*
 main function
 */

int main() {

	Row row[] = {
					{ "dollar", 3, '$' },
					{ "star", 5, '*' },
					{ "wave", 7, '~' },
					{ "dot", 1, '.' },
					{ "", 0, '\0' }
	            };
	int sum;

	do {
		cout << endl;
		show(row);
		cout <<endl;
		cout << "Player: " << turn() <<endl;
		move(row);

		sum = 0;
		for (int i = 0; i < 4; i++) {
			sum += row[i].count;
		}
	} while (sum != 0);
	     cout << endl;
        if (sum == 0)
		cout << "Player: " << turn() << " wins!" << endl;

	return 0;

}
